package rsa;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by moham on 3/15/2016.
 */

public class keyCreation {
    HugeUnsignedInteger primeNum;
    HugeUnsignedInteger e;
    HugeUnsignedInteger d;
    HugeUnsignedInteger n;


    public keyCreation(HugeUnsignedInteger prime){
        if(isPrime(prime))
            this.primeNum = prime;
    }

    public boolean isPrime (HugeUnsignedInteger prime){
        if(prime.returnLargeNum().length() == 1){//if single digit
            if(prime.returnNumArray()[0] <= 1 ) return false;
            else if(prime.returnNumArray()[0] <= 3) return true;
        }


    }
    private void makeKeyFiles() throws IOException {

        FileWriter pubKey = new FileWriter("publicKey");
        pubKey.write("<rsakey>\r\n" +
                "\t<evalue>"+e.toString()+"</evalue>\r\n" +
                "\t<nvalue>"+n.toString()+"</nvalue>\r\n" +
                "</rsakey>\r\n");
        pubKey.close();

        FileWriter privKey = new FileWriter("privateKey");
        privKey.write("<rsakey>\r\n" +
                "\t<dvalue>"+d.toString()+"</evalue>\r\n" +
                "\t<nvalue>"+n.toString()+"</nvalue>\r\n" +
                "</rsakey>\r\n");
        privKey.close();

    }

}

