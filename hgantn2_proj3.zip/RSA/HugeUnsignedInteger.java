package rsa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Lelu Dallas
 */
public class HugeUnsignedInteger {

    public void destroyHUI(){
        int size = this.hugeInt.size();
        for (int i = 0; i < size; i++)
            this.hugeInt.remove(0);
    }

    public HugeUnsignedInteger cloneHUI(){
        HugeUnsignedInteger clone = new HugeUnsignedInteger("");
        int size = this.hugeInt.size();
        for(int i = 0; i < size; i++)
            clone.hugeInt.add(this.hugeInt.get(i));
        return clone;
    }

    public ArrayList<Integer> hugeInt = new ArrayList<>();

    //constructor, takes a string
    public HugeUnsignedInteger(String input){
        //parse prime into array
        for(int i = 0; i < input.length(); i++)
            hugeInt.add(Character.getNumericValue(input.charAt(i)));

        //reverse so the least significant numbers line up
        Collections.reverse(hugeInt);


    }

    public void add(HugeUnsignedInteger x, HugeUnsignedInteger y){

        int paddingToAdd, largest, ySize, xSize;

        xSize = x.hugeInt.size();
        ySize = y.hugeInt.size();

        //**add 0s equal to difference of the size of the numbers**//

        //if x is bigger pad y
        if( x.hugeInt.size() > y.hugeInt.size() ){
            paddingToAdd = x.hugeInt.size() - y.hugeInt.size();
            largest = x.hugeInt.size();

            for(int i = 0; i < paddingToAdd; i++)
                y.hugeInt.add(0);
        }

        //if y is bigger pad x
        else if( x.hugeInt.size() < y.hugeInt.size() ){
            paddingToAdd = y.hugeInt.size() - x.hugeInt.size();
            largest = y.hugeInt.size();
            for(int i = 0; i < paddingToAdd; i++)
                x.hugeInt.add(0);
        }
        //y and x are equal, chose one arbitrarily
        else
            largest = x.hugeInt.size();


        //perform addition
        for(int i = 0; i < largest; i++){
            int val;

            //carry the 1
            if( (x.hugeInt.get(i) + y.hugeInt.get(i)) >= 10 ){

                //break up for addition
                List<Integer> digits = new ArrayList<>();

                //number to break up
                int n = x.hugeInt.get(i) + y.hugeInt.get(i);
                while (n > 0) {
                    digits.add(n%10);
                    n/=10;
                }
                //put the 10s place number in the list
                //only place where we add to the list in this if statement
                //the rest handles adding 1 to the next digit



                //check if we need to append a 0, array size grows by 1
                if((i+1) > x.hugeInt.size()-1){
                    x.hugeInt.add(i+1, 0);
                    y.hugeInt.add(i+1, 0);
                    x.hugeInt.set(i+1, x.hugeInt.get(i + 1) + 1);
                    val = digits.get(0);
                    this.hugeInt.add(val);
                    this.hugeInt.add((x.hugeInt.get(i+1)+ y.hugeInt.get(i+1)));

                }

                //check if we need to append a 0, array size grows by 1
                else if((i+1) > y.hugeInt.size()-1){
                    y.hugeInt.add(i+1, 0);
                    x.hugeInt.add(i+1, 0);
                    y.hugeInt.set(i+1, y.hugeInt.get(i + 1) + 1);
                    val = digits.get(0);
                    this.hugeInt.add(val);
                    this.hugeInt.add((y.hugeInt.get(i+1)+ x.hugeInt.get(i+1)));
                }
                else if (x.hugeInt.size() > y.hugeInt.size()){
                    val = digits.get(0);
                    this.hugeInt.add(val);
                    x.hugeInt.set(i+1, x.hugeInt.get(i + 1) + 1);
                    this.hugeInt.add((x.hugeInt.get(i+1)) + (y.hugeInt.get(i+1)));

                }
                else if(x.hugeInt.size() < y.hugeInt.size()){
                    val = digits.get(0);
                    this.hugeInt.add(val);
                    y.hugeInt.set(i+1, y.hugeInt.get(i + 1) + 1);
                    this.hugeInt.add((x.hugeInt.get(i+1)) + (y.hugeInt.get(i+1)));
                }

                else{
                    y.hugeInt.set(i+1, y.hugeInt.get(i + 1) + 1);
                    val = digits.get(0);
                    this.hugeInt.add(val);
                }


            }//end handling carry addition

            //regular addition
            else {

                if((i+1) > x.hugeInt.size()-1){
                    x.hugeInt.add(i+1, x.hugeInt.get(i));
                    y.hugeInt.add(i+1, y.hugeInt.get(i));
                    val = x.hugeInt.get(i+1) + y.hugeInt.get(i+1);
                    this.hugeInt.add(val);
                }
                else if((i+1) > y.hugeInt.size()-1 ){
                    y.hugeInt.add(i+1, 0);
                    x.hugeInt.add(i+1, 0);
                    val = x.hugeInt.get(i) + y.hugeInt.get(i);
                    this.hugeInt.add(val);
                }
                else{
                    val = x.hugeInt.get(i) + y.hugeInt.get(i);
                    this.hugeInt.add(val);
                }

            }//end regular addition 

        }//end for loop the performs addition


    }//end ADD


    //for subraction, to make sure we dont have a negative number
    public boolean checkIsLess(HugeUnsignedInteger x){//checks if this < x

        int digitX;//Takes the digit of the huge int at a specific location and uses it to compare
        int digitY;//Takes the digit of the huge int at a specific location and uses it to compare
        boolean isEqual = true;//makes sure to check if x != y, false means not equal true means equal
        //if the size of x is greater then we have y < x
        if(x.hugeInt.size() > this.hugeInt.size())
            return true;
        // if the size of y is bigger than x, then we have y > x
        else if (x.hugeInt.size() < this.hugeInt.size())
            return false;
        //Check each digit and compare starting at the most significant digit, last element in the array
        else {
            for (int i = x.hugeInt.size() - 1; i > -1; i--){
                digitX = x.hugeInt.get(i);
                digitY = this.hugeInt.get(i);
                if(digitX < digitY)
                    return false;
                else if (digitX != digitY){
                    isEqual = false;
                }
            }

        }
        if(!isEqual)
            return true;
        else
            return false;
    }//End of checkIsLess

    public boolean checkIsLEQ(HugeUnsignedInteger left){ //checks to see if this <= left
        int digitX;//Takes the digit of the huge int at a specific location and uses it to compare
        int digitY;//Takes the digit of the huge int at a specific location and uses it to compare


        //if the size of x is greater then we can subtract y from x
        if(left.hugeInt.size() > this.hugeInt.size())
            return true;
            // if the size of y is bigger than x, then we have y > x
        else if (left.hugeInt.size() < this.hugeInt.size())
            return false;
            //Check each digit and compare starting at the most significant digit, last element in the array
        else {
            for (int i = left.hugeInt.size() - 1; i > -1; i--){
                digitX = left.hugeInt.get(i);
                digitY = this.hugeInt.get(i);
                if(digitX < digitY)
                    return false;
            }
        }

        return true;
    }//End of checkIsLEQ

    public boolean checkIsGreater(HugeUnsignedInteger x){//checks if this > x

        int digitX;//Takes the digit of the huge int at a specific location and uses it to compare
        int digitY;//Takes the digit of the huge int at a specific location and uses it to compare
        boolean isEqual = true;//makes sure to check if x != y, false means not equal true means equal
        //if the size of x is greater then we have y > x
        if(this.hugeInt.size() > x.hugeInt.size())
            return true;
            // if the size of y is bigger than x, then we have y < x
        else if (this.hugeInt.size() < x.hugeInt.size())
            return false;
            //Check each digit and compare starting at the most significant digit, last element in the array
        else {
            for (int i = x.hugeInt.size() - 1; i > -1; i--){
                digitX = x.hugeInt.get(i);
                digitY = this.hugeInt.get(i);
                if(digitX > digitY)
                    return false;
                else if (digitX != digitY){
                    isEqual = false;
                }
            }

        }
        if(!isEqual)
            return true;
        else
            return false;
    }//End of checkIsGreater

    public boolean checkIsGEQ(HugeUnsignedInteger left){ //checks to see if this >= left
        int digitX;//Takes the digit of the huge int at a specific location and uses it to compare
        int digitY;//Takes the digit of the huge int at a specific location and uses it to compare


        //if the size of x is greater then we can subtract y from x
        if(this.hugeInt.size() > left.hugeInt.size())
            return true;
            // if the size of y is bigger than x, then we have y > x
        else if (this.hugeInt.size() < left.hugeInt.size())
            return false;
            //Check each digit and compare starting at the most significant digit, last element in the array
        else {
            for (int i = left.hugeInt.size() - 1; i > -1; i--){
                digitX = left.hugeInt.get(i);
                digitY = this.hugeInt.get(i);
                if(digitX > digitY)
                    return false;
            }
        }

        return true;
    }//End of checkIsGEQ

    public boolean checkIsEqual(HugeUnsignedInteger x){//checks to see if x == this
        int digitX;//Takes the digit of the huge int at a specific location and uses it to compare
        int digitY;//Takes the digit of the huge int at a specific location and uses it to compare

        //if size(x) != size(y) then they are not equal
        if(x.hugeInt.size() != this.hugeInt.size())
            return false;

        else {
            for (int i = x.hugeInt.size() - 1; i > -1; i--){
                digitX = x.hugeInt.get(i);
                digitY = this.hugeInt.get(i);
                if(digitX != digitY)
                    return false;
            }
        }

        return true;
    }//End of checkIsEqual



    //X-Y
    public void subtraction(HugeUnsignedInteger x, HugeUnsignedInteger y){

        //Check to see that x is bigger so that subtraction does not result in a negative number
        if(!(y.checkIsLEQ(x))){
            System.exit(-1);
        }

        HugeUnsignedInteger scrap = y;


        int paddingToAdd, lengthOfX;

        paddingToAdd = x.hugeInt.size() - scrap.hugeInt.size();
        lengthOfX = x.hugeInt.size();

        //pad y with 0s so the numbers match length
        for(int i = 0; i < paddingToAdd; i++)
            scrap.hugeInt.add(0);





        System.out.println("\nx:");
        for(int i = 0; i < x.hugeInt.size(); i++)
            System.out.print(x.hugeInt.get(i));

        System.out.println("\nscrap:");
        for(int i = 0; i < scrap.hugeInt.size(); i++)
            System.out.print(scrap.hugeInt.get(i));

        System.out.println("\ny:\n");
        for(int i = 0; i < y.hugeInt.size(); i++)
            System.out.print(y.hugeInt.get(i));



        //perform the subtraction, one index at a time
        for(int i = 0; i < lengthOfX; i++){
            int val;
            if( scrap.hugeInt.get(i) != 0 ){
                if( x.hugeInt.get(i) > scrap.hugeInt.get(i) ){
                    val = x.hugeInt.get(i) - scrap.hugeInt.get(i);
                    this.hugeInt.add(val);
                }
                else if( x.hugeInt.get(i) < scrap.hugeInt.get(i) ){
                    if(x.hugeInt.get(i+1) == 0){
                        int j = i + 1;
                        while(x.hugeInt.get(j) == 0){
                            x.hugeInt.set(j, 9);
                            j++;
                        }
                        x.hugeInt.set(j, x.hugeInt.get(j) - 1);
                        x.hugeInt.set(i, x.hugeInt.get(i) + 10);
                        val = x.hugeInt.get(i) - scrap.hugeInt.get(i);
                        this.hugeInt.add(val);
                    }
                    else{
                        x.hugeInt.set(i + 1, x.hugeInt.get(i + 1) - 1);
                        x.hugeInt.set(i, x.hugeInt.get(i) + 10);
                        val = x.hugeInt.get(i) - scrap.hugeInt.get(i);
                        this.hugeInt.add(val);
                    }
                }

                else
                    this.hugeInt.add(0);

            }
            else
                this.hugeInt.add(x.hugeInt.get(i));
        }//end for loop the performs subtraction

        System.out.println("beforeY " + y.hugeInt);
        int i = y.hugeInt.size()- 1;
        while(y.hugeInt.get(i) == 0 && this.hugeInt.size() != 1) {
            y.hugeInt.remove(i);
            i--;
        }

        System.out.println("afterY: " + y.hugeInt);
        System.out.println("beforeThis " + this.hugeInt);

        i = this.hugeInt.size()- 1;
        while(this.hugeInt.get(i) == 0 && this.hugeInt.size() != 1) {
            this.hugeInt.remove(i);
            i--;
        }

        System.out.println("aftery: " + y.hugeInt);
        System.out.println("afterthis: " + this.hugeInt);
    }//end SUBTRACTION


    public HugeUnsignedInteger division(HugeUnsignedInteger dividend, HugeUnsignedInteger divisor) { //dividend / divisor
        HugeUnsignedInteger zero = new HugeUnsignedInteger("0");
        HugeUnsignedInteger quotient = new HugeUnsignedInteger("");
        HugeUnsignedInteger remainder = dividend.cloneHUI();
        HugeUnsignedInteger one = new HugeUnsignedInteger("1");
        if(divisor.checkIsEqual(zero))
            System.exit(-1);

        else if(dividend.checkIsEqual(divisor)){
            quotient.hugeInt.add(1);
        }

        else if (dividend.checkIsLess(divisor)) {
            quotient.hugeInt.add(0);
        }

        else {
            while (remainder.checkIsGEQ(divisor)){
                HugeUnsignedInteger scrapQ = new HugeUnsignedInteger("");
                HugeUnsignedInteger scrapR = new HugeUnsignedInteger("");

                scrapQ.add(quotient, one); //Q = Q + 1
                quotient.destroyHUI();
                quotient = scrapQ.cloneHUI();

                scrapR.subtraction(remainder, divisor);
                remainder.destroyHUI();
                remainder = scrapR.cloneHUI();
            }
        }


        this.hugeInt = quotient.hugeInt;

        for(int i = this.hugeInt.size() - 1; i > 0; i--){
            this.hugeInt.remove(i);
        }

        return remainder;
    }

    public void multiply(HugeUnsignedInteger x, HugeUnsignedInteger y){

        int totalSize = x.hugeInt.size() + y.hugeInt.size();
        int carry;
        int base = 10;

        for(int i = 0; i < totalSize; i++){
            this.hugeInt.add(0);
        }

        for(int i = 0; i < y.hugeInt.size(); i++){
            carry = 0;
            for(int j = 0; j < x.hugeInt.size(); j++){
                this.hugeInt.set((j+i), this.hugeInt.get(j+i) + carry + (x.hugeInt.get(j)*y.hugeInt.get(i)));
                carry = this.hugeInt.get(j+i)/base;
                this.hugeInt.set((j+i), (this.hugeInt.get(j+i))%base);

            }
            this.hugeInt.set((i+x.hugeInt.size()), this.hugeInt.get(i+x.hugeInt.size())+carry);
        }

        int i = this.hugeInt.size()- 1;
        while(this.hugeInt.get(i) == 0 && this.hugeInt.size() != 1) {
            this.hugeInt.remove(i);
            i--;
        }

    }

    public HugeUnsignedInteger powMod (HugeUnsignedInteger e, HugeUnsignedInteger M, HugeUnsignedInteger n){//e = exponent, M = base, n = mod
        HugeUnsignedInteger one = new HugeUnsignedInteger("1");
        HugeUnsignedInteger zero = new HugeUnsignedInteger("0");
        HugeUnsignedInteger two = new HugeUnsignedInteger("2");
        HugeUnsignedInteger result = one.cloneHUI();
        int count = 0;

        if(n.checkIsEqual(one)){
            return zero;
        }

        HugeUnsignedInteger r = new HugeUnsignedInteger("");
        HugeUnsignedInteger scrap = r.division(M, n).cloneHUI();
        M.destroyHUI();
        M = scrap.cloneHUI();

        while(e.checkIsGreater(zero)) {
            HugeUnsignedInteger r1 = new HugeUnsignedInteger("");
            if (r1.division(e, two).checkIsEqual(one)){
                HugeUnsignedInteger r2 = new HugeUnsignedInteger("");
                r2.multiply(result, M);
                HugeUnsignedInteger r3 = new HugeUnsignedInteger("");
                result.destroyHUI();
                result = r3.division(r2, n);
            }
            HugeUnsignedInteger r4 = new HugeUnsignedInteger("");
            r4.division(e, two);
            e.destroyHUI();
            e = r4;
            HugeUnsignedInteger r5 = new HugeUnsignedInteger("");
            r5.multiply(M, M);
            M.destroyHUI();
            HugeUnsignedInteger r6 = new HugeUnsignedInteger("");
            M = r6.division(r5, n);
            count++;
        }
        System.out.println(count);
        return result;
    }
}