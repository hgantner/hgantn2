/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rsa;

/**
 *
 * @author Lelu Dallas
 */
public class RsaAlgorithm {
    
    private HugeUnsignedInteger p;
    private HugeUnsignedInteger q;
    HugeUnsignedInteger n = new HugeUnsignedInteger("");
    HugeUnsignedInteger phi = new HugeUnsignedInteger("");
    HugeUnsignedInteger p_1 = new HugeUnsignedInteger("");
    HugeUnsignedInteger q_1 = new HugeUnsignedInteger("");
    HugeUnsignedInteger one = new HugeUnsignedInteger("1");
    HugeUnsignedInteger zero = new HugeUnsignedInteger("0");
    HugeUnsignedInteger e = new HugeUnsignedInteger("0");

    
    public HugeUnsignedInteger getP(){
        return p;
    }
    
    public void setP(HugeUnsignedInteger temp){
        p = temp;
        System.out.println("P INPUT: " + p.hugeInt);
    }
    
    public void setQ(HugeUnsignedInteger temp){
        q = temp;
        System.out.println("Q INPUT: " + q.hugeInt);

    }
    
    public RsaAlgorithm(){
        
    }
    
    public void keys(){
        //n=p*q//
        n.multiply(p, q);
        
        //p_1 = p-1//
        p_1.subtraction(p, one);
        
        //q_1 = q-1//
        q_1.subtraction(q, one);
        
        //phi=(p-1)*(q-1)//
        phi.multiply(p_1, q_1);
        
        //get e//
        //e<n, e coprime phi//
        e = egcd(phi, n);
        
        
    }
    
    
    //takes phi, loop through until gcd = 1
    public HugeUnsignedInteger egcd(HugeUnsignedInteger m, HugeUnsignedInteger n) {
        
        while(e != one && e.checkIsGEQ(n)){
            
            e.add(e, one);
            
            while (m != zero) {
                if (e.checkIsGreater(m))
                    e.subtraction(e, m);
                else
                    m.subtraction(m, e);
            }
        }
        return e;
    }


    
    
}
