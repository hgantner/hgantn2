/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rsa;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

/**
 *
 * @author Lelu Dallas
 */
public class GUI extends JFrame implements ActionListener {
    
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JPanel box;
    private JTextField getBlockSize;
    public HugeUnsignedInteger p_input;
    public HugeUnsignedInteger q_input;
    public RsaAlgorithm rsa = new RsaAlgorithm();
    private File f = new File("primeNumbers.rsc");
    public int blockSize;
    public JFileChooser getFile;
    
    //set up GUI
    public GUI(){
        
        super("RSA ENCRYPTION");
        
        getFile = new JFileChooser();   
        
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        getContentPane().setLayout(new BorderLayout());
        
   
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        mainPanel.add(Box.createRigidArea(new Dimension(50, 10)));
        
        box = new JPanel(new GridLayout(4, 1));
        
         //set up border
        Border thickBorder = new LineBorder(Color.lightGray, 3);
        
        /*
        getBlockSize = new JTextField(10);
        getBlockSize.setMaximumSize(getBlockSize.getPreferredSize());
        getBlockSize.setAlignmentX(Component.TOP_ALIGNMENT);
        box.add(getBlockSize);
        */
        
        button1 = new JButton(" Key Creation ");
        button1.setBackground(Color.white);
        button1.setBorder(thickBorder);
        button1.setPreferredSize(new Dimension(190, 50));
        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button1.setFont(button1.getFont().deriveFont(Font.BOLD, 24f));
        button1.addMouseListener(new MouseAdapter() {
            @Override   
            public void mouseClicked (MouseEvent e)
            {
               if (SwingUtilities.isLeftMouseButton(e))
               {
                   
                   String option = JOptionPane.showInputDialog("Would you like to enter your own p and q values?\n\t\ty/n");
                   
                   if("y".equals(option)){
                        //get p and q
                        String p = JOptionPane.showInputDialog("Please enter p");
                        p_input = new HugeUnsignedInteger(p);
                        rsa.setP(p_input);

                        String q = JOptionPane.showInputDialog("Please enter q");
                        q_input = new HugeUnsignedInteger(q);
                        rsa.setQ(q_input);
                   }
                   
                   //create random values
                   
                   else{
                       int i;
                       int j;
                       try {
                           String p = randomPrime(f);
                           p_input = new HugeUnsignedInteger(p);
                           for(i=0; i < p_input.hugeInt.size(); i++){
                               if(p_input.hugeInt.get(i) == -1)
                                 p_input.hugeInt.remove(i);  
                           }
                           rsa.setP(p_input);
                       } 
                       catch (FileNotFoundException ex) {
                           Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                       } catch (IOException ex) {
                           Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                       }
                       
                       try {
                           String q = randomPrime(f);
                           q_input = new HugeUnsignedInteger(q);
                           for(j = 0; j < q_input.hugeInt.size(); j++){
                               if(q_input.hugeInt.get(j) == -1)
                                 q_input.hugeInt.remove(j);  
                           }
                           rsa.setQ(q_input);
                       }
                       catch (FileNotFoundException ex) {
                           Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                       } catch (IOException ex) {
                           Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                       }
                       
                   }//end choose random
                   
               }
            }
        });
        box.add(button1);
        
        button2 = new JButton(" Block a File ");
        button2.setBackground(Color.white);
        button2.setBorder(thickBorder);
        button2.setPreferredSize(new Dimension(190, 50));
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setFont(button2.getFont().deriveFont(Font.BOLD, 24f));
        button2.addMouseListener(new MouseAdapter() {
            @Override   
            public void mouseClicked (MouseEvent e)
            {
               if (SwingUtilities.isLeftMouseButton(e))
               {
                   String blockFile = JOptionPane.showInputDialog("Enter the name of your file to be encoded");
                   String block = JOptionPane.showInputDialog("Enter the block size");
                   blockSize = Integer.parseInt(block);
                   
                   
               }
            }
        });
        box.add(button2);
        
        button3 = new JButton(" Unblock a File ");
      //  button3.addActionListener(printListener);
        button3.setBackground(Color.white);
        button3.setBorder(thickBorder);
        button3.setPreferredSize(new Dimension(190, 50));
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setFont(button3.getFont().deriveFont(Font.BOLD, 24f));
        box.add(button3);
        
        button4 = new JButton(" Encrypt/Decrypt ");
      //  button4.addActionListener(printListener);
        button4.setBackground(Color.white);
        button4.setBorder(thickBorder);
        button4.setPreferredSize(new Dimension(190, 50));
        button4.setAlignmentX(Component.CENTER_ALIGNMENT);
        button4.setFont(button4.getFont().deriveFont(Font.BOLD, 24f));        
        box.add(button4);
        
        JPanel west = new JPanel(new GridBagLayout());
        west.add(box);
        mainPanel.add(west, BorderLayout.CENTER);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(mainPanel, BorderLayout.CENTER);
        setSize( 275, 275 );
        setVisible( true );
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static String randomPrime(File f) throws FileNotFoundException, IOException{
        
     BufferedReader reader = new BufferedReader(new FileReader(f));   
     String line = reader.readLine();
     List<String> lines = new ArrayList<>();
     
     while (line != null) {
         lines.add(line);
         line = reader.readLine();
     }
     Random r = new Random();
     String randomLine = lines.get(r.nextInt(lines.size()));
     return randomLine;      
  }
    
}
