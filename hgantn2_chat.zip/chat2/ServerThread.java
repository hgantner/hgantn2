package chat2;
/*	serverThread.java
*
*	Allows us to easily have multiple chatServer connections to keep
* 	track of multiple clients at once.
*/

import java.net.*;
import java.io.*;

public class ServerThread extends Thread {
	private chatServer cs;//Our little chatServer
	private Socket csSocket;
	private DataInputStream csStreamIn;
	private DataOutputStream csStreamOut;
	private int csID = 666;//Yeah, I went there >:o

	public ServerThread(chatServer _server, Socket _socket)
	{
		super();
		cs = _server;
		csSocket = _socket;
		csID = csSocket.getPort();
	}
	public void send(String words)
	{
		try//Try to send the words to the other end
		{
			csStreamOut.writeUTF(words);//Goodbye words
			csStreamOut.flush();//Don't forget to flush
		}
		catch(IOException ioEx)
		{
			System.out.println(csID + " ERROR sending: " + ioEx.getMessage());
			cs.removeUser(csID);
			interrupt();
		}
	}
	public int getCsID(){ return csID;}//Since the port is made private
	
	//Open our streams
	public void openThread() throws IOException
	{
		csStreamIn = new DataInputStream(new BufferedInputStream(csSocket.getInputStream()));
		csStreamOut = new DataOutputStream(new BufferedOutputStream(csSocket.getOutputStream()));
		//Get our streams from our Chat Server socket
	}
	
	//Close out of our socket and streams
	public void closeThread() throws IOException
	{
		if(csSocket.isClosed() == false)
			csSocket.close();
		if(csStreamIn != null) 
			csStreamIn.close();
		if(csStreamOut != null)
			csStreamOut.close();
	}
	
	// What else goes in a Java Thread? These things are interesting.
	// (by that I mean I have no idea)

}