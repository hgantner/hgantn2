/*	chatClient.java
 *
 * 	Allows a client to connect to a specific IP and port (via a chatServer
 * 	instance) and send/receive messages.
 */

import java.net.*;
import java.io.*;

public class chatClient implements Runnable{
	private InetAddress rAddress;
	private Socket rSocket;
	private Thread thread = null;
	private DataInputStream streamIn;
	private DataOutputStream streamOut;
	private chatThread user = null;
	
	// other vars as necessary

	public chatClient(String raddr, int port){
		System.out.println("Joining the Matrix.... ");
		try {
			rAddress = InetAddress.getByName(raddr);
		} catch (UnknownHostException e){
			// host is janked up error
			System.err.println(e);
			System.err.println("Error: "raddr" is invalid");	
//TODO: add this to GUI somehow? Maybe separate it out from the constructor																
//		with a return value or something.
		}
		
		try {
			rSocket = new Socket(rAddress, port);
			System.out.println("We're in boys!"  rSocket);
			start();
		} catch (IOException e){
			// could not open socket error
			System.err.println(e);
			System.err.println("Error: could not reach "raddr" on port "port);
		}
	}
		
	public void run()
	{
		
	}

	public void speak(String words)
	{
		//Probably will be over-ridden by GUI application commands
	}
	
	public void start() throws IOException
	{
		streamIn = new DataInputStream(System.in);//This is where the user inputs their message
		streamOut = new DataOutputStream(rSocket.getOutputStream());//Send the output stream through our sock
		
		if(thread == null)
		{
			user = new chatThread(this, rSocket);//Create a new user!
			thread = new Thread(this);
			thread.start();
		}
	}
	
	public void stop()
	{
		if(thread != null)//We have a running thread
		{
			thread.interrupt();
			thread  = null;//clear it out
		}
		
		try{
			if( streamIn != null) 
				streamIn.close();
			if(streamOut != null) 
				streamOut.close();
			if(rSocket != null) 
				rSocket.close();
		}
		catch(IOException ioEx)
		{
			System.err.println("Error Occured while attempting to close");
			user.close();
			user.stop();
		}
		
		
	}
	
	public static void main(String args[])
	{
		chatClient user = null;
		user = new chatClient(args[0], Integer.parseInt(args[1]));//This is where the user is created. IP & Port go in here.
	}
/*	
	
	// Don't leave the socket open (same as chatServer)
	public void closeConnection(){
		if(rSocket == null)	// Avoid checking for NullPointerAcception
			return;
		try {
			rSocket.close();
		} catch (IOException e){
			System.err.println(e);
		}
	}*/
} 