/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.StyledDocument;
import java.awt.TextField;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.text.DefaultCaret;


/**
 *
 * @author Lelu Dallas
 */
public class ChatClientGUI extends JFrame implements ActionListener{
   
    JButton connect; //goes in the JPANEL menu
    JButton disconnect;
    JButton send; //placed in the JPANEL textfield
    JMenuBar menubar;
    JMenu menu;
    JMenuItem menuItem;
    JPanel menuPanel;
    JPanel frame; //frame to hold all the addition panels, to be added to JFRAME
    JPanel IPinput; //holds the IP, port, and connect buttons, as wll and the drop down menus
    JPanel displayChat; //hold the JTEXTFIELD that displays the chat history
    JTextArea display; //displays chat history, goes into the JPANEL displayChat
    JPanel textField; //holds the user input string and the send button
    JTextField input; //user input, put into the 
    JTextField IP; //ip input, put into JPANEL menu
    JTextField port; //port input, put into JPANEL menu
    JTextArea users;
    JComboBox fileMenu;
    String IPinfo;
    String portInfo;
    String chatInput;
    public ChatServer server;
    public int port1;
    
        
    public static void main(String args[]){
        ChatClientGUI client = new ChatClientGUI();
        client.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    }
    
    public ChatClientGUI(){
        
        super("Chat Client");
        
        //frame to hold all the panels, to be added to JFRAME
        frame = new JPanel();
        frame.setLayout(new BoxLayout(frame, BoxLayout.PAGE_AXIS));
        
        getContentPane();
        
        //create drop down menus
        //create the menu bar
        menubar = new JMenuBar();
        
        //build the first menu
        menu = new JMenu("File");
        menu.setPreferredSize(new Dimension(35, 1));
        menu.setMnemonic(KeyEvent.VK_F);
        menubar.add(menu);
        
        //add items to menu
        JMenuItem menuItem = new JMenuItem("Connections", KeyEvent.VK_N);
        menu.add(menuItem);
        
        //IP and Port input panel
        IPinput = new JPanel(new FlowLayout());
        
        //ip input
        IP = new JTextField(20);
        IP.addActionListener(this);
        IP.setEditable(true);

        //port input
        port = new JTextField(20);
        port.addActionListener(this);
        port.setEditable(true);
        
        //label for ip
        JTextField IPlabel = new JTextField("IP");
        IPlabel.setEditable(false);
        
        //label for port
        JTextField Portlabel = new JTextField("PORT");
        Portlabel.setEditable(false);
        
        
        //
        //add components to panel
        //
        IPinput.add(IPlabel); //add IP label
        IPinput.add(IP); //add IP input textfield
        IPinput.add(Portlabel);
        IPinput.add(port); //add port input textfield
        connect = new JButton( "connect");
        connect.addMouseListener(new MouseAdapter() {
            @Override   
            public void mouseClicked (MouseEvent e)
            {
               if (SwingUtilities.isLeftMouseButton(e))
               {
                  server = new chatServer(port1);
                  
               }
            }
        });
        disconnect = new JButton( "disconnect");
        disconnect.addMouseListener(new MouseAdapter() {
            @Override   
            public void mouseClicked (MouseEvent e)
            {
               if (SwingUtilities.isLeftMouseButton(e))
               {
                   //connection code
                  
               }
            }
        });
        IPinput.add(connect); //add connect button
        IPinput.add(disconnect);
        
        
        //
        //JPANEL holds the JTextfield for the chat history
        //
        displayChat = new JPanel(new FlowLayout());
        
        //uneditable display field for displaying the chat history
        display = new JTextArea(20, 40);
        display.setEditable(false);
        
        users = new JTextArea(20, 10);
        users.setBackground(Color.lightGray);
        users.setEditable(false);

        //auto scroll
        DefaultCaret caret = (DefaultCaret)display.getCaret();
        caret.setUpdatePolicy(DefaultCaret.OUT_BOTTOM);

        //set scroll pane
        JScrollPane scroll = new JScrollPane(display);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setViewportView(display);
        displayChat.add(scroll); //add JTEXTFIELD to JPANEL
        displayChat.add(users);
        
        //JPanel for holding the text field and the send button
        textField = new JPanel(new FlowLayout());
        //Textfield for userinput 
        input = new JTextField(" ", 50);
        input.setEditable(true);
        input.addActionListener(this);
        textField.add(input);
        
        send = new JButton( "send");
        send.addMouseListener(new MouseAdapter() {
            @Override   
            public void mouseClicked (MouseEvent e)
            {
               if (SwingUtilities.isLeftMouseButton(e))
               {
                   chatInput = input.getText();
                   
                   display.append(IPinfo + ">" + chatInput + "\n");
                   
                   
                   display.setCaretPosition(display.getDocument().getLength());
               }
            }
        });
        textField.add(send);
        
        //
        //add the menu, displaychat, and text input to the JFRAME in BoxLayout
        //
        frame.add(menubar, BorderLayout.PAGE_START);
        frame.add(IPinput); //ip and port input
        frame.add(displayChat); //display chat history
        frame.add(textField); //enter text for chat
        add(frame); //add frame to JFRAME
    
        setSize(600, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

        
    }
    
  
    @Override
    public void actionPerformed(ActionEvent e){
        portInfo = port.getText(); //get port input
        port1 = Integer.parseInt(portInfo);
        IPinfo = IP.getText(); //get ip input
        chatInput = input.getText();
        
        
        
        display.append(IPinfo + ">" + chatInput + "\n");
        display.setCaretPosition(display.getDocument().getLength());

                
    }


}
