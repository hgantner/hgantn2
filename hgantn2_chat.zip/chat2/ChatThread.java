package chat2;

import java.net.*;
import java.io.*;

public class ChatThread extends Thread{
	private Socket sock = null;
	private ChatClient user = null;
	private DataInputStream streamIn = null;
	
	public ChatThread(ChatClient _user, Socket _sock)
	{
		user = _user;
		sock = _sock;
		open();
		start();
	}
	
	public void open()
	{
		try
		{
			streamIn = new DataInputStream(sock.getInputStream());
			
		}
		catch(IOException ioEx)
		{
			
			System.err.println("Input occured whi1e g3tting Err0r! " + ioEx);
			user.stop();
		}
	}
	
	public void close()
	{
		try
		{
			if(streamIn != null)
				streamIn.close();//End the input stream if it's been created
		}
		catch(IOException ioEx)
		{
			System.err.println("Error while closing input stream " + ioEx);
		}
	}
	
	public void run()
	{
		while(true)
		{
			try{
				user.speak(streamIn.readUTF());
			
			}
			catch(IOException ioEx)
			{
				System.err.println("Couldn't listen. Gone Deaf m8. " + ioEx);
				user.stop();
			}
		}
	}

}
