package chat2;

import java.net.*;
import java.io.*;

public class ChatServer implements Runnable{
	private ServerThread users[] = new ServerThread[50];
	private ServerSocket sSocket;
	private Socket serviceSocket; //Think this should be in the serverThread
	private Thread thread = null;
	private int userCount = 0;//To track the number of penguins in a given leap-year

	// A port is given
	public ChatServer(int port){
		try {
			System.out.println("We haz port " + port + ", sit yer azz down ...");
			sSocket = new ServerSocket(port);
			System.out.println("All praise Server: " + sSocket);
			start();//Get yer needles out gramma! It's threading time!
		} catch (IOException e){
			System.err.println("Error: could not open server socket on port "+port);
		}
	}
	
	// Constructor when no port is given, i.e. random port
		public ChatServer(){
			try {
				sSocket = new ServerSocket(0);
			} catch (IOException e){
				System.err.println("Error: could not open server socket on random port");
				return;
			}
		}
	
	public static void main(String args[])
	{
		ChatServer server = null;
		server = new ChatServer(4444);
	}
		
		
	//Start zee threads
	public void start()
	{
		if(thread == null)
		{
			thread = new Thread(this);
			thread.start();
		}
	}
	
	//Guess what this does, I dare you
	public void stop()
	{
		if(thread != null)
		{
			thread.interrupt();
			thread = null;
		}
	}
	
	//Search through our list of users for the desired user
	private int searchUsers(int ID)
	{
		for(int i = 0; i < userCount; i++)
		{
			if(users[i].getCsID() == ID)
				return i;
		}
		return 666;//You dont' want to end up here... or do you?
	}
	
	//Send a message to the everyone connected
	//Could/should be duplicated and modified to create a specific "Chat room" and not all users
	public synchronized void sendToAll(int ID, String words)
	{
		for(int i = 0; i < userCount; i++)
		{
			users[i].send("User " +ID + " Yells: " + words);
		}
	}
	
	//GTFO!!! Synchro-ed so they don;t break stuff since we're re-arranging our array of users
	public synchronized void removeUser(int ID)
	{
		int usrIdx = searchUsers(ID);//Index of the user to remove
		if(usrIdx > -1 && usrIdx < 666)//We have a valid position
		{
			ServerThread temp = users[usrIdx];
			System.out.println("User " + ID + " has left!");
			if(usrIdx < userCount - 1)//Check to see if we removed someone that wasn't the last user
			{
				for(int i = usrIdx + 1; i < userCount; i++)
				{
					users[i-1] = users[i];//Leave no gaps in your arrays!
				}
				userCount--;//Man down!!
			}
			try
			{
				temp.closeThread();
			}
			catch(IOException ioEx)
			{
				System.out.println("Error! Thread has not been closed! This is not a drill! " + ioEx);
				
			}
			temp.interrupt();
		}
		
	}
	
	//Adding a new user to the world
	public void addUser(Socket sock)
	{
		System.out.println("User arriving from " + sock);
		users[userCount] = new ServerThread(this, sock);
		//Needles and yarn time!~
		try{
			users[userCount].openThread();
			users[userCount].start();
			userCount++;//We have indoctirnated a poor pitiful soul
			
		}
		catch(IOException ioEx)
		{
			System.out.println("Error!! User was found to be a heathen! " + ioEx);
		}
	}
	
	public void run()//
	{
		while(thread != null)
		{
			System.out.println("Welcome...");
			acceptConnection();
		}
	}

	public void acceptConnection(){
		try {
			serviceSocket = sSocket.accept();
		} catch(IOException e){
			System.out.println(e);
			return;
		}
	}
/*
	// Don't leave the socket open (same as chatClient)
	public void closeConnection(){
		if(sSocket == null)	// Avoid checking for NullPointerAcception
			return;
		try {
			sSocket.close();
		} catch (IOException e){
			System.err.println(e);
			return;
		}
	}
/*	
	// Return the port currently in use by the serverSocket
	public int getPort(){
		return sSocket.getLocalPort();
	}

	//TODO: implement "try...catch" for sock = ServerSocket(port number); try something = sock.accept();

	// BASIC USAGE (obviously temporary)
	/*public static void main(String args[]){
		System.out.println("opening server connection on random port...");
		chatServer cs = new chatServer();
		chatClient cc = new chatClient("127.0.0.1",cs.getPort());
		
		cs.acceptConnection();
		
		cs.closeConnection();
		cc.closeConnection();
	}*/
	
}
