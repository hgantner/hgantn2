//ahusse21 - hgantn2 - mjense7
//CS 342 Proj5

//This class runs the game

package tetris;


import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.*;

public class Tetris extends JFrame {
	
	JLabel score;
        public Tetris game;
   
    public Tetris() {

    	//Initialize the game
        score = new JLabel(" 0");//Set score to 0
        add(score, BorderLayout.SOUTH);
        Board board = new Board(this);
        add(board);
        board.start();

        setSize(400, 800);
        setTitle("Tetris");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        //Setiing up the menu
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fMenu = new JMenu("File");
        JMenu hMenu = new JMenu("Help");
        menuBar.add(fMenu);
        menuBar.add(hMenu);
        
        JMenuItem menuItem = new JMenuItem("Quit", KeyEvent.VK_Q);
        menuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt){
        		quitMenuActionPerformed(evt);
        	}
        });
        JMenuItem rItem = new JMenuItem("Restart");
        rItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt){
        		resetGame(evt);
        	}
        });
        setJMenuBar(menuBar);
        
        JMenuItem aItem = new JMenuItem("About", KeyEvent.VK_A);
        aItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt){
                    about(evt);
                }
        });
        JMenuItem iItem = new JMenuItem("Instructions");
        iItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt){
                    instructions(evt);
                }
        });
        
        hMenu.add(iItem);
        hMenu.add(aItem);//Add about under Help
        fMenu.add(rItem);
        fMenu.add(menuItem);//Add quit under File
        
        
        
   }

   public JLabel getScore() {
       return score;
   }
   
   private void quitMenuActionPerformed(ActionEvent evt)
   {
	   System.exit(0);
   }
   
   
   
   private void resetGame(ActionEvent e)
    {
        dispose();
        Tetris tetris = new Tetris();
        tetris.setLocationRelativeTo(null);
        tetris.setVisible(true);
    }
   private void about(ActionEvent e){
       
        JOptionPane.showMessageDialog(this, "ahusse21 - hgantn2 - mjense7\n Welcome to Tetris. Program 5 for 342");
   }
   
   private void instructions(ActionEvent e){
       
        JOptionPane.showMessageDialog(this, "Key board:\nUp and Down to rotate, and left and right to move, Space to drop piece to bottom\n\nMenu:\nQuit and Reset\nAbout and Instructions\n\nScoring on the bottom ");
   }

    public static void main(String[] args) {
    	 
    	 
    	

        Tetris game = new Tetris();//Instantiate the game
        game.setLocationRelativeTo(null);
        game.setVisible(true);
        
        

    } 
}